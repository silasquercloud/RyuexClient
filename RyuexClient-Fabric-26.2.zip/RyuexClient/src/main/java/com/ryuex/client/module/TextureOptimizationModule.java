package com.ryuex.client.module;

public final class TextureOptimizationModule extends Module {
    public TextureOptimizationModule() {
        super("Texture Optimization", Category.RENDER, true);
    }
}
