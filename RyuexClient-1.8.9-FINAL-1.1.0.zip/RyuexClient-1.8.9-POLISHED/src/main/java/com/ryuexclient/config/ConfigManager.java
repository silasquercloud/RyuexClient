package com.ryuexclient.config;

import com.google.gson.*;
import com.ryuexclient.RyuexClient;
import com.ryuexclient.gui.Theme;
import com.ryuexclient.gui.HudEditorGui;
import com.ryuexclient.module.Module;
import java.io.*;
import java.util.Map;

public class ConfigManager {
    private File file;
    private File profiles;

    public void load(){ load("default"); }
    public void load(String profile){
        file = new File(Path.dir(), profile + ".json");
        profiles = new File(Path.dir(), "profiles");
        if(!file.exists()) return;
        try {
            JsonObject r = new JsonParser().parse(new FileReader(file)).getAsJsonObject();
            JsonObject m=r.getAsJsonObject("modules");
            if(m!=null) for(Module x:RyuexClient.modules.getModules()) if(m.has(x.getName())) x.setEnabled(m.get(x.getName()).getAsBoolean());
            JsonObject keys=r.getAsJsonObject("keys");
            if(keys!=null) for(Module x:RyuexClient.modules.getModules()) if(keys.has(x.getName())) x.setKey(keys.get(x.getName()).getAsInt());
            JsonObject t=r.getAsJsonObject("theme");
            if(t!=null){ if(t.has("accent"))Theme.accent=t.get("accent").getAsInt(); if(t.has("opacity"))Theme.opacity=t.get("opacity").getAsFloat(); if(t.has("compact"))Theme.compact=t.get("compact").getAsBoolean(); }
            JsonObject hud=r.getAsJsonObject("hud");
            if(hud!=null) HudEditorGui.loadPositions(hud);
        }catch(Exception ignored){}
    }
    public void save(){ save("default"); }
    public void save(String profile){
        File dir=Path.dir(); if(!dir.exists())dir.mkdirs();
        file=new File(dir,profile+".json");
        JsonObject r=new JsonObject(),m=new JsonObject(),keys=new JsonObject();
        for(Module x:RyuexClient.modules.getModules()){m.addProperty(x.getName(),x.isEnabled());keys.addProperty(x.getName(),x.getKey());}
        r.add("modules",m); r.add("keys",keys);
        JsonObject t=new JsonObject();t.addProperty("accent",Theme.accent);t.addProperty("opacity",Theme.opacity);t.addProperty("compact",Theme.compact);r.add("theme",t);
        r.add("hud",HudEditorGui.savePositions());
        try(FileWriter w=new FileWriter(file)){new GsonBuilder().setPrettyPrinting().create().toJson(r,w);}catch(IOException ignored){}
    }
    public void reset(){
        for(Module x:RyuexClient.modules.getModules()) x.setEnabled(false);
        Theme.accent=0xFF55DFFF; Theme.opacity=0.94f; Theme.compact=false;
        save();
    }
}
