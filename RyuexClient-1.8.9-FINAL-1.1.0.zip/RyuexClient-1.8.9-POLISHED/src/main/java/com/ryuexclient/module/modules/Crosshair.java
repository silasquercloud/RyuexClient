package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.Theme;
import net.minecraft.client.gui.Gui;
public class Crosshair extends Module{
 public Crosshair(){super("Crosshair",Category.HUD,0);}
 public void onRender2D(float p){int w=mc.displayWidth/mc.gameSettings.guiScale,h=mc.displayHeight/mc.gameSettings.guiScale,x=w/2,y=h/2;int c=Theme.accent;Gui.drawRect(x-1,y-6,x+1,y-2,c);Gui.drawRect(x-1,y+2,x+1,y+6,c);Gui.drawRect(x-6,y-1,x-2,y+1,c);Gui.drawRect(x+2,y-1,x+6,y+1,c);}
}
