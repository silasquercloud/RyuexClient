package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.HudEditorGui;
import net.minecraft.item.ItemStack;
public class ArmorStatus extends Module{
 public ArmorStatus(){super("ArmorStatus",Category.HUD,0);}
 public void onRender2D(float p){if(mc.thePlayer==null)return;int[]q=HudEditorGui.pos(this,8,100);int y=q[1];for(int i=0;i<4;i++){ItemStack s=mc.thePlayer.inventory.armorInventory[i];if(s!=null)mc.fontRendererObj.drawStringWithShadow(""+Math.max(0,s.getMaxDamage()-s.getItemDamage()),q[0]+i*28,y,0xFFFFFFFF);}}
}
