package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.HudEditorGui;
import com.ryuexclient.gui.Theme;
public class TabInfo extends Module{
 public TabInfo(){super("TabInfo",Category.HUD,0);}
 public void onRender2D(float p){int[]q=HudEditorGui.pos(this,8,58);mc.fontRendererObj.drawStringWithShadow("RyuexClient 1.8.9",q[0],q[1],Theme.accent);}
}
