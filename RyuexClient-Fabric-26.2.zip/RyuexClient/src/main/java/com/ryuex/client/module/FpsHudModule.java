package com.ryuex.client.module;

public final class FpsHudModule extends Module {
    public FpsHudModule() {
        super("FPS HUD", Category.RENDER, true);
    }
}
