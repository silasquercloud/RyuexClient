package com.ryuexclient.gui;

public final class Theme {
    public static int accent = 0xFF55DFFF;
    public static int background = 0xFF0D0F14;
    public static int panel = 0xFF171A22;
    public static int panel2 = 0xFF20242E;
    public static int text = 0xFFF2F4F7;
    public static int muted = 0xFF8E98A6;
    public static float opacity = 0.94f;
    public static boolean compact = false;

    private Theme() {}
    public static int withAlpha(int color, float a) {
        int aa = Math.max(0, Math.min(255, (int)(a * 255f)));
        return (aa << 24) | (color & 0x00FFFFFF);
    }
    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar=(a>>16)&255, ag=(a>>8)&255, ab=a&255;
        int br=(b>>16)&255, bg=(b>>8)&255, bb=b&255;
        return 0xFF000000 | ((int)(ar+(br-ar)*t)<<16) | ((int)(ag+(bg-ag)*t)<<8) | (int)(ab+(bb-ab)*t);
    }
}
