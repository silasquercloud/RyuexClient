package com.ryuex.client.module;

public final class CoordinatesModule extends Module {
    public CoordinatesModule() {
        super("Coordinates", Category.PLAYER, true);
    }
}
