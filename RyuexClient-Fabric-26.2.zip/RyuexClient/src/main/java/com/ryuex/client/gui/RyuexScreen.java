package com.ryuex.client.gui;

import com.ryuex.client.module.Category;
import com.ryuex.client.module.Module;
import com.ryuex.client.module.ModuleManager;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class RyuexScreen extends Screen {
    private Category selected = Category.RENDER;

    public RyuexScreen(Screen parent) {
        super(Component.literal("Ryuex Client"));
    }

    @Override
    protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearWidgets();

        int panelWidth = 520;
        int panelX = (this.width - panelWidth) / 2;
        int categoryY = 56;

        int x = panelX + 12;
        for (Category category : Category.values()) {
            final Category target = category;
            this.addRenderableWidget(
                    Button.builder(Component.literal(category.name()), button -> {
                        selected = target;
                        rebuild();
                    }).bounds(x, categoryY, 92, 20).build()
            );
            x += 100;
        }

        List<Module> modules = ModuleManager.byCategory(selected);
        int y = 100;

        for (Module module : modules) {
            String state = module.isEnabled() ? "ON" : "OFF";
            this.addRenderableWidget(
                    Button.builder(
                            Component.literal(module.getName() + "  [" + state + "]"),
                            button -> {
                                module.toggle();
                                rebuild();
                            }
                    ).bounds(panelX + 18, y, 250, 22).build()
            );
            y += 28;
        }

        this.addRenderableWidget(
                Button.builder(Component.literal("Close"), button -> onClose())
                        .bounds(panelX + panelWidth - 100, this.height - 42, 82, 20)
                        .build()
        );
    }

    @Override
    public void extractRenderState(
            GuiGraphicsExtractor graphics,
            int mouseX,
            int mouseY,
            float delta
    ) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);

        int panelWidth = 520;
        int panelHeight = Math.min(360, this.height - 40);
        int panelX = (this.width - panelWidth) / 2;
        int panelY = (this.height - panelHeight) / 2;

        graphics.fill(0, 0, this.width, this.height, 0x99000000);
        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xF0101118);
        graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 3, 0xFF7C4DFF);

        graphics.text(this.font, "RYUEX", panelX + 18, panelY + 14, 0xFFFFFFFF, true);
        graphics.text(this.font, "Client  •  Minecraft 26.2", panelX + 18, panelY + 29, 0xFF9FA6B2, false);
        graphics.text(this.font, selected.name(), panelX + 18, 84, 0xFFBFA8FF, true);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
