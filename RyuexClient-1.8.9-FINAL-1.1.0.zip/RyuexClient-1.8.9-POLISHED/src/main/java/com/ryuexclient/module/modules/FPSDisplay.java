package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.HudEditorGui;
public class FPSDisplay extends Module{
 public FPSDisplay(){super("FPS",Category.HUD,0);}
 public void onRender2D(float p){int[]q=HudEditorGui.pos(this,8,8);mc.fontRendererObj.drawStringWithShadow("FPS: "+mc.getDebugFPS(),q[0],q[1],0xFFFFFFFF);}
}
