package com.ryuex.client.module;

import com.ryuex.client.config.RyuexConfig;

public abstract class Module {
    private final String name;
    private final Category category;
    private boolean enabled;

    protected Module(String name, Category category, boolean defaultEnabled) {
        this.name = name;
        this.category = category;
        this.enabled = RyuexConfig.getBoolean(configKey(), defaultEnabled);
    }

    public final String getName() {
        return name;
    }

    public final Category getCategory() {
        return category;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;

        this.enabled = enabled;
        RyuexConfig.setBoolean(configKey(), enabled);

        if (enabled) onEnable();
        else onDisable();
    }

    private String configKey() {
        return "module." + name.toLowerCase().replace(' ', '_') + ".enabled";
    }

    protected void onEnable() {}
    protected void onDisable() {}
}
