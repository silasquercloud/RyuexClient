package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.HudEditorGui;
import com.ryuexclient.gui.Theme;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
public class Keystrokes extends Module{
 public Keystrokes(){super("Keystrokes",Category.HUD,0);}
 public void onRender2D(float p){int[]q=HudEditorGui.pos(this,8,70);int x=q[0],y=q[1];draw("W",x+18,y,mc.gameSettings.keyBindForward.isKeyDown());draw("A",x,y+20,mc.gameSettings.keyBindLeft.isKeyDown());draw("S",x+18,y+20,mc.gameSettings.keyBindBack.isKeyDown());draw("D",x+36,y+20,mc.gameSettings.keyBindRight.isKeyDown());}
 private void draw(String s,int x,int y,boolean d){Gui.drawRect(x-2,y-2,x+16,y+14,Theme.withAlpha(d?Theme.accent:Theme.panel2,.9f));FontRenderer f=mc.fontRendererObj;f.drawStringWithShadow(s,x+3,y+2,Theme.text);}
}
