package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import org.lwjgl.input.Keyboard;
public class ToggleSprint extends Module{
    private boolean toggled;
    private boolean lastPress;
    public ToggleSprint(){super("ToggleSprint",Category.MOVEMENT,Keyboard.KEY_NONE);}
    public void onTick(){
        if(mc.thePlayer==null)return;
        boolean press=mc.gameSettings.keyBindSprint.isKeyDown();
        if(press && !lastPress) toggled=!toggled;
        lastPress=press;
        if(toggled && mc.thePlayer.moveForward>0.0f) mc.thePlayer.setSprinting(true);
        else if(!toggled) mc.thePlayer.setSprinting(false);
    }
    protected void onDisable(){toggled=false;lastPress=false;if(mc.thePlayer!=null)mc.thePlayer.setSprinting(false);}
}
