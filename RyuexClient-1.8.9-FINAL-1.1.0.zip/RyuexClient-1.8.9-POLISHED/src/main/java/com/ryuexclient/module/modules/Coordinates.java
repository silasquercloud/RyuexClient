package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.HudEditorGui;
public class Coordinates extends Module{
 public Coordinates(){super("Coordinates",Category.HUD,0);}
 public void onRender2D(float p){if(mc.thePlayer==null)return;String s=String.format("XYZ: %.1f %.1f %.1f",mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ);int[]q=HudEditorGui.pos(this,8,44);mc.fontRendererObj.drawStringWithShadow(s,q[0],q[1],0xFFFFFFFF);}
}
