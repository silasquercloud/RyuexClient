package com.ryuexclient.gui;

import com.google.gson.JsonObject;
import com.ryuexclient.RyuexClient;
import com.ryuexclient.module.Module;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class HudEditorGui extends GuiScreen {
    private static final Map<String,int[]> POS = new LinkedHashMap<String,int[]>();
    private Module dragging; private int dx,dy;
    private long opened;

    public HudEditorGui(){ opened=System.currentTimeMillis(); }
    public static int[] pos(Module m,int defX,int defY){
        int[] p=POS.get(m.getName()); if(p==null){p=new int[]{defX,defY};POS.put(m.getName(),p);} return p;
    }
    public static JsonObject savePositions(){JsonObject o=new JsonObject();for(Map.Entry<String,int[]> e:POS.entrySet()){JsonObject p=new JsonObject();p.addProperty("x",e.getValue()[0]);p.addProperty("y",e.getValue()[1]);o.add(e.getKey(),p);}return o;}
    public static void loadPositions(JsonObject o){for(String k:o.keySet()){try{JsonObject p=o.getAsJsonObject(k);POS.put(k,new int[]{p.get("x").getAsInt(),p.get("y").getAsInt()});}catch(Exception ignored){}}}

    protected void drawScreen(int mx,int my,float partial){
        drawDefaultBackground();
        Gui.drawRect(0,0,width,height,Theme.withAlpha(Theme.background,Theme.opacity));
        mc.fontRendererObj.drawStringWithShadow("HUD EDITOR",16,14,Theme.text);
        mc.fontRendererObj.drawStringWithShadow("Drag • Right click = toggle • ESC = save",16,28,Theme.muted);
        for(Module m:RyuexClient.modules.getModules()) if(m.getCategory()==Module.Category.HUD){
            int[] p=pos(m,8,40+RyuexClient.modules.getModules().indexOf(m)*22);
            int bw=Math.max(70,mc.fontRendererObj.getStringWidth(m.getName())+18);
            Gui.drawRect(p[0]-4,p[1]-4,p[0]+bw,p[1]+16,Theme.withAlpha(m.isEnabled()?Theme.accent:Theme.panel2,0.88f));
            mc.fontRendererObj.drawStringWithShadow(m.getName(),p[0]+4,p[1],Theme.text);
        }
        super.drawScreen(mx,my,partial);
    }
    protected void mouseClicked(int mx,int my,int button)throws IOException{
        for(Module m:RyuexClient.modules.getModules()) if(m.getCategory()==Module.Category.HUD){
            int[] p=pos(m,8,40);int bw=Math.max(70,mc.fontRendererObj.getStringWidth(m.getName())+18);
            if(mx>=p[0]-4&&mx<=p[0]+bw&&my>=p[1]-4&&my<=p[1]+16){
                if(button==1){m.toggle();RyuexClient.config.save();}
                else {dragging=m;dx=mx-p[0];dy=my-p[1];}
                return;
            }
        }
        super.mouseClicked(mx,my,button);
    }
    protected void mouseClickMove(int mx,int my,int button,long time){if(dragging!=null&&button==0){int[]p=pos(dragging,8,40);p[0]=Math.max(2,mx-dx);p[1]=Math.max(2,my-dy);}}
    protected void mouseReleased(int mx,int my,int button){if(button==0&&dragging!=null){dragging=null;RyuexClient.config.save();}}
    protected void keyTyped(char c,int key)throws IOException{if(key==1){RyuexClient.config.save();mc.displayGuiScreen(new RyuexClickGui());return;}super.keyTyped(c,key);}
}
