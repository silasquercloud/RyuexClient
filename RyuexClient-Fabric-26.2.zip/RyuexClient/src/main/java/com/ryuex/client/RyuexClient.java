package com.ryuex.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.ryuex.client.config.RyuexConfig;
import com.ryuex.client.gui.RyuexScreen;
import com.ryuex.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public final class RyuexClient implements ClientModInitializer {
    public static final String MOD_ID = "ryuex";

    public static final KeyMapping OPEN_MENU = KeyMappingHelper.registerKeyMapping(
            new KeyMapping(
                    "key.ryuex.open_menu",
                    InputConstants.Type.KEYSYM,
                    InputConstants.KEY_RIGHT_SHIFT,
                    KeyMapping.Category.register(
                            Identifier.fromNamespaceAndPath(MOD_ID, "main")
                    )
            )
    );

    @Override
    public void onInitializeClient() {
        RyuexConfig.load();
        ModuleManager.initialize();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_MENU.consumeClick()) {
                Minecraft.getInstance().gui.setScreen(new RyuexScreen(null));
            }
        });
    }
}
