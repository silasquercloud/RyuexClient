package com.ryuex.client.module;

public enum Category {
    COMBAT,
    MOVEMENT,
    RENDER,
    PLAYER,
    MISC
}
