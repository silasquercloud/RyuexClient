package com.ryuexclient.gui;

import com.ryuexclient.RyuexClient;
import com.ryuexclient.module.Module;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RyuexClickGui extends GuiScreen {
    private Module.Category category=Module.Category.COMBAT;
    private Module selected;
    private int scroll;
    private boolean waitingKey;
    private String search="";
    private int accentIndex=0;
    private final int[] accents={0xFF55DFFF,0xFF9B6CFF,0xFFFF5F87,0xFFFFB84D,0xFF65E572,0xFF48A9FF};
    private long opened;

    public RyuexClickGui(){opened=System.currentTimeMillis();}
    protected void drawScreen(int mx,int my,float partial){
        drawDefaultBackground();
        float fade=Math.min(1f,(System.currentTimeMillis()-opened)/180f);
        Gui.drawRect(0,0,width,height,Theme.withAlpha(Theme.background,Theme.opacity*fade));
        int side=142; Gui.drawRect(10,10,side, height-10,Theme.withAlpha(Theme.panel,Theme.opacity));
        mc.fontRendererObj.drawStringWithShadow("RYUEX",24,22,Theme.accent);
        mc.fontRendererObj.drawString("1.8.9 • PvP CLIENT",24,36,Theme.muted);
        int y=62;
        for(Module.Category c:Module.Category.values()){
            boolean sel=c==category;
            Gui.drawRect(18,y-3,side-8,y+15,Theme.withAlpha(sel?Theme.accent:Theme.panel2,sel?0.26f:0.35f));
            mc.fontRendererObj.drawString(c.name(),26,y,sel?Theme.text:Theme.muted); y+=22;
        }
        mc.fontRendererObj.drawString("RSHIFT  GUI",24,height-34,Theme.muted);
        mc.fontRendererObj.drawString("H  HUD EDITOR",24,height-21,Theme.muted);

        int left=156; Gui.drawRect(left,10,width-10,height-10,Theme.withAlpha(Theme.panel,Theme.opacity));
        mc.fontRendererObj.drawStringWithShadow(category.name(),left+16,20,Theme.text);
        mc.fontRendererObj.drawString("Search: "+(search.length()==0?"type here":search),left+16,36,Theme.muted);
        if(waitingKey)mc.fontRendererObj.drawStringWithShadow("PRESS A KEY FOR "+(selected==null?"MODULE":selected.getName()),left+190,20,Theme.accent);

        List<Module> list=filtered(); int row=58-scroll; int cardH=30;
        for(Module m:list){
            if(row+cardH>=48&&row<height-18){
                boolean active=m.isEnabled(), focus=m==selected;
                Gui.drawRect(left+12,row,width-190,row+cardH,Theme.withAlpha(focus?Theme.panel2:Theme.background,0.92f));
                if(active)Gui.drawRect(left+12,row,left+15,row+cardH,Theme.accent);
                mc.fontRendererObj.drawStringWithShadow(m.getName(),left+24,row+7,active?Theme.text:Theme.muted);
                mc.fontRendererObj.drawString(m.keyName(),width-176,row+7,Theme.muted);
                mc.fontRendererObj.drawString(active?"ON":"OFF",width-74,row+7,active?Theme.accent:Theme.muted);
            }
            row+=cardH+5;
        }
        int panelX=width-178; Gui.drawRect(panelX,58,width-20,height-20,Theme.withAlpha(Theme.background,0.9f));
        mc.fontRendererObj.drawStringWithShadow("APPEARANCE",panelX+12,70,Theme.text);
        mc.fontRendererObj.drawString("Opacity",panelX+12,91,Theme.muted);
        int barX=panelX+12,barY=105,barW=142;
        Gui.drawRect(barX,barY,barX+barW,barY+5,Theme.panel2);Gui.drawRect(barX,barY,barX+(int)(barW*Theme.opacity),barY+5,Theme.accent);
        mc.fontRendererObj.drawString(String.format("%.0f%%",Theme.opacity*100),barX,116,Theme.text);
        mc.fontRendererObj.drawString("Accent",panelX+12,140,Theme.muted);
        for(int i=0;i<accents.length;i++)Gui.drawRect(panelX+12+i*21,153,panelX+28+i*21,169,accents[i]);
        mc.fontRendererObj.drawString("H = edit HUD",panelX+12,188,Theme.muted);
        mc.fontRendererObj.drawString("RSHIFT = open",panelX+12,202,Theme.muted);
        mc.fontRendererObj.drawString("ESC = close",panelX+12,216,Theme.muted);
        if(selected!=null){
            mc.fontRendererObj.drawStringWithShadow("SELECTED",panelX+12,245,Theme.text);
            mc.fontRendererObj.drawString(selected.getName(),panelX+12,260,Theme.muted);
            mc.fontRendererObj.drawString("Key: "+selected.keyName(),panelX+12,276,Theme.muted);
            mc.fontRendererObj.drawString("Click = toggle",panelX+12,294,Theme.muted);
            mc.fontRendererObj.drawString("K = rebind",panelX+12,308,Theme.muted);
        }
        super.drawScreen(mx,my,partial);
    }
    private List<Module> filtered(){List<Module> out=new ArrayList<Module>();for(Module m:RyuexClient.modules.getModules())if(m.getCategory()==category&&(search.length()==0||m.getName().toLowerCase().contains(search.toLowerCase())))out.add(m);return out;}
    protected void mouseClicked(int mx,int my,int button)throws IOException{
        int side=142;
        if(mx>=18&&mx<side){int y=62;for(Module.Category c:Module.Category.values()){if(my>=y-4&&my<=y+17){category=c;selected=null;scroll=0;return;}y+=22;}}
        int left=156,row=58-scroll;for(Module m:filtered()){if(row+30>=48&&row<height-18&&mx>=left+12&&mx<=width-190&&my>=row&&my<=row+30){selected=m;if(button==0){m.toggle();RyuexClient.config.save();}else if(button==1){waitingKey=true;}return;}row+=35;}
        int panelX=width-178;if(mx>=panelX+12&&mx<=panelX+154&&my>=105&&my<=125){Theme.opacity=Math.max(.35f,Math.min(1f,(mx-(panelX+12))/142f));RyuexClient.config.save();return;}
        if(mx>=panelX+12&&mx<panelX+140&&my>=153&&my<=169){int i=(mx-(panelX+12))/21;if(i>=0&&i<accents.length){Theme.accent=accents[i];RyuexClient.config.save();return;}}
        super.mouseClicked(mx,my,button);
    }
    protected void handleMouseInput()throws IOException{super.handleMouseInput();int wheel=Mouse.getDWheel();if(wheel!=0)scroll=Math.max(0,scroll-(wheel>0?35:-35));}
    protected void keyTyped(char c,int key)throws IOException{
        if(waitingKey&&selected!=null){if(key==1){waitingKey=false;return;}selected.setKey(key);waitingKey=false;RyuexClient.config.save();return;}
        if(key==1){RyuexClient.config.save();mc.displayGuiScreen(null);return;}
        if(key==Keyboard.KEY_H){mc.displayGuiScreen(new HudEditorGui());return;}
        if(key==Keyboard.KEY_K&&selected!=null){waitingKey=true;return;}
        if(key==Keyboard.KEY_BACK){if(search.length()>0)search=search.substring(0,search.length()-1);return;}
        if(c>=32&&c<=126)search+=c;
        super.keyTyped(c,key);
    }
}
