package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.HudEditorGui;
import net.minecraft.client.network.NetworkPlayerInfo;
public class PingDisplay extends Module{
 public PingDisplay(){super("Ping",Category.HUD,0);}
 public void onRender2D(float p){int ping=0;if(mc.thePlayer!=null&&mc.getNetHandler()!=null){NetworkPlayerInfo i=mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());if(i!=null)ping=i.getResponseTime();}int[]q=HudEditorGui.pos(this,8,32);mc.fontRendererObj.drawStringWithShadow("Ping: "+ping+"ms",q[0],q[1],0xFFFFFFFF);}
}
