package com.ryuexclient.module;
import com.ryuexclient.module.modules.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import java.util.*;
public class ModuleManager {
 private final List<Module> list=new ArrayList<Module>();
 public ModuleManager(){
  list.add(new ToggleSprint()); list.add(new Fullbright()); list.add(new Zoom());
  list.add(new FPSDisplay()); list.add(new CPSDisplay()); list.add(new PingDisplay());
  list.add(new Coordinates()); list.add(new Keystrokes()); list.add(new ArmorStatus());
  list.add(new Crosshair()); list.add(new TabInfo());
 }
 public List<Module> getModules(){return list;}
 public Module get(String n){for(Module m:list)if(m.getName().equalsIgnoreCase(n))return m;return null;}
 @SubscribeEvent public void tick(TickEvent.ClientTickEvent e){
  if(e.phase!=TickEvent.Phase.END)return;
  for(Module m:list)if(m.isEnabled())m.onTick();
 }
 @SubscribeEvent public void render(RenderGameOverlayEvent.Post e){
  if(e.type!=RenderGameOverlayEvent.ElementType.ALL)return;
  for(Module m:list)if(m.isEnabled())m.onRender2D(e.partialTicks);
 }
}
