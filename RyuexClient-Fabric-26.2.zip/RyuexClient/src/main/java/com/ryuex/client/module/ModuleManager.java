package com.ryuex.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean initialized;

    private ModuleManager() {}

    public static void initialize() {
        if (initialized) return;
        initialized = true;

        MODULES.add(new TextureOptimizationModule());
        MODULES.add(new FpsHudModule());
        MODULES.add(new CoordinatesModule());
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<Module> byCategory(Category category) {
        return MODULES.stream()
                .filter(module -> module.getCategory() == category)
                .toList();
    }
}
