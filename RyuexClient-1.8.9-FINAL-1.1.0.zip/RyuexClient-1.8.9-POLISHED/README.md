# RyuexClient 1.8.9 — FINAL RC 1.1.0

Cliente Forge 1.8.9 focado em PvP legítimo, HUD e personalização.

## Interface
- ClickGUI categorizada e translúcida
- Pesquisa de módulos
- Keybind editor
- Cores de destaque
- Controle de transparência
- Seleção de módulo e estado ON/OFF
- HUD Editor com arrastar e salvar

## HUD e módulos
- FPS
- CPS
- Ping
- Coordinates
- Keystrokes
- ArmorStatus
- Crosshair
- TabInfo
- ToggleSprint
- Fullbright
- Zoom

## Configuração
As configurações ficam em `.minecraft/ryuexclient/default.json` e incluem módulos, teclas, tema e posições do HUD.

## Build
Forge 1.8.9: 11.15.1.2318. Java alvo: 8. O workflow de GitHub Actions usa Java 8 e Gradle 4.10.3.

OptiFine não é redistribuído pelo projeto; ele deve ser instalado separadamente no ambiente 1.8.9.

## Segurança do projeto
O cliente não inclui automação de combate como KillAura, Reach, Aimbot ou AutoClicker.

Consulte `REPORT.md` para o relatório técnico e a porcentagem de completude.
