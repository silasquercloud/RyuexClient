package com.ryuexclient;
import com.ryuexclient.config.ConfigManager;
import com.ryuexclient.gui.RyuexClickGui;
import com.ryuexclient.module.ModuleManager;
import com.ryuexclient.module.Module;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid=RyuexClient.MOD_ID,name=RyuexClient.NAME,version=RyuexClient.VERSION,acceptedMinecraftVersions="[1.8.9]")
public class RyuexClient {
 public static final String MOD_ID="ryuexclient", NAME="RyuexClient", VERSION="1.1.0";
 public static ModuleManager modules; public static ConfigManager config; public static KeyBinding guiKey;
 @Mod.EventHandler public void init(FMLInitializationEvent e){
  modules=new ModuleManager(); config=new ConfigManager(); config.load();
  guiKey=new KeyBinding("RyuexClient GUI",Keyboard.KEY_RSHIFT,"RyuexClient");
  ClientRegistry.registerKeyBinding(guiKey);
  MinecraftForge.EVENT_BUS.register(this); MinecraftForge.EVENT_BUS.register(modules);
 }
 @SubscribeEvent public void key(InputEvent.KeyInputEvent e){
  if(guiKey.isPressed()) { Minecraft.getMinecraft().displayGuiScreen(new RyuexClickGui()); return; }
  if(Keyboard.getEventKeyState()){
   int k=Keyboard.getEventKey();
   for(Module m:modules.getModules()) if(m.getKey()==k && k!=Keyboard.KEY_NONE) m.toggle();
   config.save();
  }
 }
 @SubscribeEvent public void fov(FOVUpdateEvent e){
  if(modules!=null) for(Module m:modules.getModules()) if(m.isEnabled()) e.newfov=m.onFov(e.newfov);
 }
}
