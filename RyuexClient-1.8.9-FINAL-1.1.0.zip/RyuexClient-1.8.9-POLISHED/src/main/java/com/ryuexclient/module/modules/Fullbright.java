package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
public class Fullbright extends Module{
 private float old;
 public Fullbright(){super("Fullbright",Category.RENDER,0);}
 protected void onEnable(){old=mc.gameSettings.gammaSetting;mc.gameSettings.gammaSetting=1000f;}
 protected void onDisable(){mc.gameSettings.gammaSetting=old;}
}