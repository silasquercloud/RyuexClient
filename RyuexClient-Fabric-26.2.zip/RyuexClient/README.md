# ⚡ RYUEX CLIENT

A clean, modular and performance-focused Minecraft Java client/mod for **Fabric 26.2**.

## ✨ Current foundation

- Right Shift opens the Ryuex menu
- Custom client GUI
- Categories: Combat, Movement, Render, Player, Misc
- Toggleable module system
- Persistent configuration in `config/ryuex.properties`
- Texture Optimization module foundation
- FPS HUD and Coordinates module foundations
- Fabric 26.2 + Java 25 toolchain
- Designed to avoid raw OpenGL so the project can coexist with the experimental Vulkan renderer

## 🗂️ Structure

```text
src/main/java/com/ryuex/client/
├── RyuexClient.java
├── config/
├── gui/
└── module/
    ├── Category.java
    ├── Module.java
    ├── ModuleManager.java
    ├── TextureOptimizationModule.java
    ├── FpsHudModule.java
    └── CoordinatesModule.java
```

## 🧪 Build

Minecraft 26.2 development uses Java 25. Fabric's 26.2 guidance recommends Loom 1.17 and Gradle 9.5.1.

If the Gradle wrapper files are not present in your environment, run:

```bash
gradle wrapper --gradle-version 9.5.1
```

Then:

```bash
./gradlew build
```

The production JAR is generated in:

```text
build/libs/
```

## 🎮 Controls

**Right Shift** → open Ryuex menu.

The key can also be changed in Minecraft's Controls settings.

## ⚙️ Texture Optimization

The first version exposes the feature as a module and persists its state. The actual texture/resource pipeline optimization will be implemented separately so it can be tested safely with Sodium and Minecraft 26.2's rendering backends.

## 🧭 Roadmap

- [x] Project foundation
- [x] Right Shift menu
- [x] GUI categories
- [x] Module toggles
- [x] Persistent config
- [ ] Full HUD renderer
- [ ] Real texture/resource optimization
- [ ] Sodium compatibility testing
- [ ] Vulkan compatibility testing
- [ ] Settings screen
- [ ] Animated Ryuex branding
- [ ] First release

---

**RYUEX** — Built for performance. Designed for PvP.
