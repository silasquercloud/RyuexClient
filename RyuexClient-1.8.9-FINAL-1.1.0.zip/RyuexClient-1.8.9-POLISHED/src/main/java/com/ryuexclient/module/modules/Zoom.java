package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import org.lwjgl.input.Keyboard;
public class Zoom extends Module{
    private float oldFov;
    public Zoom(){super("Zoom",Category.RENDER,Keyboard.KEY_C);}
    public float onFov(float fov){
        if(!isEnabled()) return fov;
        return 20.0f;
    }
}
