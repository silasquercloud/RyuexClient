package com.ryuexclient.config;
import net.minecraft.client.Minecraft;
import java.io.File;
public final class Path{
 private Path(){}
 public static File dir(){File f=new File(Minecraft.getMinecraft().mcDataDir,"ryuexclient");if(!f.exists())f.mkdirs();return f;}
}