package com.ryuexclient.module;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public abstract class Module {
    protected final Minecraft mc = Minecraft.getMinecraft();
    private final String name;
    private final Category category;
    private boolean enabled;
    private int key;

    public Module(String n, Category c, int k) { name=n; category=c; key=k; }
    public String getName(){return name;}
    public Category getCategory(){return category;}
    public boolean isEnabled(){return enabled;}
    public int getKey(){return key;}
    public void setKey(int k){key=k;}
    public void toggle(){setEnabled(!enabled);}
    public void setEnabled(boolean s){if(enabled==s)return;enabled=s;if(s)onEnable();else onDisable();}
    protected void onEnable(){}
    protected void onDisable(){}
    public void onTick(){}
    public void onRender2D(float p){}
    public float onFov(float fov){return fov;}
    public String keyName(){return key==Keyboard.KEY_NONE?"NONE":Keyboard.getKeyName(key);}
    public enum Category{COMBAT,MOVEMENT,RENDER,PLAYER,WORLD,MISC,HUD}
}
