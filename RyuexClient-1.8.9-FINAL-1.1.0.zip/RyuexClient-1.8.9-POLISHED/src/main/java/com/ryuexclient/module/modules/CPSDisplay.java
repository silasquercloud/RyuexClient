package com.ryuexclient.module.modules;
import com.ryuexclient.module.Module;
import com.ryuexclient.gui.HudEditorGui;
import org.lwjgl.input.Mouse;
public class CPSDisplay extends Module{
 private final long[] clicks=new long[40]; private int pos; private boolean last;
 public CPSDisplay(){super("CPS",Category.HUD,0);}
 public void onTick(){boolean down=Mouse.isButtonDown(0);if(down&&!last)clicks[pos++%clicks.length]=System.currentTimeMillis();last=down;}
 public void onRender2D(float p){long n=System.currentTimeMillis();int c=0;for(long t:clicks)if(t>0&&n-t<1000)c++;int[]q=HudEditorGui.pos(this,8,20);mc.fontRendererObj.drawStringWithShadow("CPS: "+c,q[0],q[1],0xFFFFFFFF);}
}
