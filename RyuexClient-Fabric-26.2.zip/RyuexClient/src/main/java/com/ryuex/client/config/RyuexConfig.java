package com.ryuex.client.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class RyuexConfig {
    private static final Properties PROPERTIES = new Properties();
    private static Path path;

    private RyuexConfig() {}

    public static void load() {
        try {
            Path configDir = Path.of("config");
            Files.createDirectories(configDir);
            path = configDir.resolve("ryuex.properties");

            if (Files.exists(path)) {
                try (InputStream in = Files.newInputStream(path)) {
                    PROPERTIES.load(in);
                }
            }
        } catch (IOException ignored) {
        }
    }

    public static boolean getBoolean(String key, boolean fallback) {
        return Boolean.parseBoolean(PROPERTIES.getProperty(key, Boolean.toString(fallback)));
    }

    public static void setBoolean(String key, boolean value) {
        PROPERTIES.setProperty(key, Boolean.toString(value));
        save();
    }

    private static void save() {
        if (path == null) return;

        try (OutputStream out = Files.newOutputStream(path)) {
            PROPERTIES.store(out, "Ryuex Client configuration");
        } catch (IOException ignored) {
        }
    }
}
